/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './AuthContext';
import { ThemeProvider } from './ThemeContext';
import { SystemProvider } from './SystemContext';
import Layout from './Layout';
import AuthPage from './components/AuthPage';
import Dashboard from './components/Dashboard';
import AlterManager from './components/AlterManager';
import Diary from './components/Diary';
import SwitchTracker from './components/SwitchTracker';
import InternalChat from './components/InternalChat';
import SocialFeed from './components/SocialFeed';
import Resources from './components/Resources';
import Settings from './components/Settings';
import ProfilePage from './components/ProfilePage';
import FriendsList from './components/FriendsList';
import DirectMessages from './components/DirectMessages';
import Notifications from './components/Notifications';
import ErrorBoundary from './components/ErrorBoundary';

const AppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [viewProfileId, setViewProfileId] = useState<string | null>(null);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const { user, loading, profile } = useAuth();

  React.useEffect(() => {
    const handleSetTab = (e: any) => {
      setActiveTab(e.detail);
      if (e.detail !== 'profile') setViewProfileId(null);
      if (e.detail !== 'messages') setActiveChatId(null);
    };
    window.addEventListener('setTab', handleSetTab);
    return () => window.removeEventListener('setTab', handleSetTab);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-zinc-950">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  const handleViewProfile = (uid: string) => {
    setViewProfileId(uid);
    setActiveTab('profile');
  };

  const handleOpenChat = (uid: string) => {
    setActiveChatId(uid);
    setActiveTab('messages');
  };

  const renderTab = () => {
    const isSinglet = profile?.isSinglet;
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'alters': return isSinglet ? <Dashboard /> : <AlterManager />;
      case 'diary': return <Diary />;
      case 'switches': return isSinglet ? <Dashboard /> : <SwitchTracker />;
      case 'chat': return isSinglet ? <Dashboard /> : <InternalChat />;
      case 'social': return <SocialFeed onAuthorClick={handleViewProfile} />;
      case 'notifications': return <Notifications />;
      case 'friends': return <FriendsList onViewProfile={handleViewProfile} onOpenChat={handleOpenChat} />;
      case 'messages': return <DirectMessages initialUserId={activeChatId || undefined} />;
      case 'profile': return <ProfilePage userId={viewProfileId || user.uid} onOpenChat={handleOpenChat} onAuthorClick={handleViewProfile} />;
      case 'resources': return <Resources />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={(tab) => {
      setActiveTab(tab);
      if (tab !== 'profile') setViewProfileId(null);
      if (tab !== 'messages') setActiveChatId(null);
    }}>
      {renderTab()}
    </Layout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <SystemProvider>
          <ThemeProvider>
            <AppContent />
          </ThemeProvider>
        </SystemProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
