import React, { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, doc, getDoc, updateDoc, arrayUnion, arrayRemove, deleteDoc, addDoc } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { UserPlus, UserMinus, MessageCircle, Shield, ShieldOff, Search, User, Check, X } from 'lucide-react';
import { UserProfile, Friendship } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

interface FriendsListProps {
  onViewProfile: (userId: string) => void;
  onOpenChat: (userId: string) => void;
}

const FriendsList: React.FC<FriendsListProps> = ({ onViewProfile, onOpenChat }) => {
  const { user, profile } = useAuth();
  const [friends, setFriends] = useState<UserProfile[]>([]);
  const [pendingRequests, setPendingRequests] = useState<(Friendship & { sender?: UserProfile })[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    // Fetch friends
    const unsubFriends = onSnapshot(doc(db, 'users', user.uid), async (snap) => {
      try {
        const data = snap.data() as UserProfile;
        if (data.friendIds && data.friendIds.length > 0) {
          const friendPromises = data.friendIds.map(id => getDoc(doc(db, 'users', id)));
          const friendSnaps = await Promise.all(friendPromises);
          setFriends(friendSnaps.map(s => ({ uid: s.id, ...s.data() } as UserProfile)));
        } else {
          setFriends([]);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    });

    // Fetch pending requests
    const pendingQ = query(
      collection(db, 'friendships'),
      where('user2Id', '==', user.uid),
      where('status', '==', 'pending')
    );
    const unsubPending = onSnapshot(pendingQ, async (snap) => {
      try {
        const requests = snap.docs.map(d => ({ id: d.id, ...d.data() } as Friendship));
        const requestsWithSender = await Promise.all(requests.map(async (req) => {
          const senderSnap = await getDoc(doc(db, 'users', req.user1Id));
          return { ...req, sender: { uid: senderSnap.id, ...senderSnap.data() } as UserProfile };
        }));
        setPendingRequests(requestsWithSender);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'friendships');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'friendships');
    });

    return () => {
      unsubFriends();
      unsubPending();
    };
  }, [user]);

  const handleAccept = async (request: Friendship) => {
    if (!user || !profile) return;
    try {
      await updateDoc(doc(db, 'friendships', request.id), { status: 'accepted' });
      await updateDoc(doc(db, 'users', user.uid), { friendIds: arrayUnion(request.user1Id) });
      await updateDoc(doc(db, 'users', request.user1Id), { friendIds: arrayUnion(user.uid) });

      await addDoc(collection(db, 'notifications'), {
        recipientId: request.user1Id,
        senderId: user.uid,
        senderName: profile.displayName || profile.systemName || 'User',
        senderAvatar: profile.avatarUrl || null,
        type: 'friend_request',
        content: 'accepted your friend request',
        timestamp: new Date().toISOString(),
        isRead: false
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `friendships/${request.id}`);
    }
  };

  const handleDecline = async (request: Friendship) => {
    try {
      await deleteDoc(doc(db, 'friendships', request.id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `friendships/${request.id}`);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    // Simplified search: by username
    const q = query(
      collection(db, 'users'),
      where('username', '==', searchQuery.trim().toLowerCase()),
      where('uid', '!=', user?.uid)
    );
    const unsub = onSnapshot(q, (snap) => {
      setSearchResults(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-[var(--text-primary)]">Friends & Social</h2>
        <p className="text-[var(--text-secondary)]">Manage your connections and find new systems.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Search */}
          <section className="bg-[var(--bg-surface)] p-8 rounded-3xl border border-[var(--bg-panel)] shadow-sm">
            <h3 className="text-xl font-bold mb-6 text-[var(--text-primary)]">Find Systems</h3>
            <div className="flex gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={20} />
                <input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSearch()}
                  className="w-full pl-12 pr-4 py-3 rounded-2xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                  placeholder="Search by username..."
                />
              </div>
              <button 
                onClick={handleSearch}
                className="px-8 py-3 bg-[var(--accent-main)] text-white rounded-2xl font-bold hover:bg-[var(--accent-hover)] transition-all shadow-lg shadow-[var(--accent-glow)]"
              >
                Search
              </button>
            </div>

            {searchResults.length > 0 && (
              <div className="mt-8 space-y-4">
                {searchResults.map(res => (
                  <div key={res.uid} className="flex items-center justify-between p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
                    <div className="flex items-center gap-4">
                      <img src={res.avatarUrl || `https://ui-avatars.com/api/?name=${res.displayName}`} className="w-12 h-12 rounded-2xl object-cover" />
                      <div>
                        <p className="font-bold text-[var(--text-primary)]">{res.displayName || res.systemName}</p>
                        <p className="text-xs text-[var(--text-muted)]">@{res.username}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => onViewProfile(res.uid)}
                      className="px-6 py-2 bg-[var(--bg-panel)] text-[var(--text-primary)] rounded-xl font-bold hover:bg-[var(--bg-surface)] transition-all"
                    >
                      View Profile
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Friends List */}
          <section className="bg-[var(--bg-surface)] p-8 rounded-3xl border border-[var(--bg-panel)] shadow-sm">
            <h3 className="text-xl font-bold mb-6 text-[var(--text-primary)]">Your Friends</h3>
            {friends.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {friends.map(friend => (
                  <div key={friend.uid} className="flex items-center justify-between p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
                    <div className="flex items-center gap-3">
                      <img src={friend.avatarUrl || `https://ui-avatars.com/api/?name=${friend.displayName}`} className="w-10 h-10 rounded-xl object-cover" />
                      <div>
                        <p className="font-bold text-sm text-[var(--text-primary)]">{friend.displayName || friend.systemName}</p>
                        <p className="text-[10px] text-[var(--text-muted)]">@{friend.username}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => onOpenChat(friend.uid)}
                        className="p-2 bg-[var(--bg-panel)] text-[var(--accent-main)] rounded-xl hover:bg-[var(--bg-surface)] transition-all"
                      >
                        <MessageCircle size={18} />
                      </button>
                      <button 
                        onClick={() => onViewProfile(friend.uid)}
                        className="p-2 bg-[var(--bg-panel)] text-[var(--text-primary)] rounded-xl hover:bg-[var(--bg-surface)] transition-all"
                      >
                        <User size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-[var(--bg-main)] rounded-3xl border border-dashed border-[var(--bg-panel)]">
                <p className="text-[var(--text-muted)]">No friends added yet.</p>
              </div>
            )}
          </section>
        </div>

        {/* Pending Requests */}
        <div className="space-y-8">
          <section className="bg-[var(--bg-surface)] p-8 rounded-3xl border border-[var(--bg-panel)] shadow-sm">
            <h3 className="text-xl font-bold mb-6 text-[var(--text-primary)]">Friend Requests</h3>
            {pendingRequests.length > 0 ? (
              <div className="space-y-4">
                {pendingRequests.map(req => (
                  <div key={req.id} className="p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
                    <div className="flex items-center gap-3 mb-4">
                      <img src={req.sender?.avatarUrl || `https://ui-avatars.com/api/?name=${req.sender?.displayName}`} className="w-10 h-10 rounded-xl object-cover" />
                      <div>
                        <p className="font-bold text-sm text-[var(--text-primary)]">{req.sender?.displayName || req.sender?.systemName}</p>
                        <p className="text-[10px] text-[var(--text-muted)]">@{req.sender?.username}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleAccept(req)}
                        className="flex-1 py-2 bg-green-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1"
                      >
                        <Check size={14} /> Accept
                      </button>
                      <button 
                        onClick={() => handleDecline(req)}
                        className="flex-1 py-2 bg-[var(--bg-panel)] text-[var(--text-secondary)] rounded-xl font-bold text-xs flex items-center justify-center gap-1"
                      >
                        <X size={14} /> Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center py-8 text-[var(--text-muted)] text-sm">No pending requests.</p>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};

export default FriendsList;
