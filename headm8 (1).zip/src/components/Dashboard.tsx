import React from 'react';
import { useSystem } from '../SystemContext';
import { useAuth } from '../AuthContext';
import { motion } from 'motion/react';
import { Activity, Users, Clock, Plus, BarChart3, Book } from 'lucide-react';
import { formatDate } from '../lib/utils';
import SwitchAnalytics from './SwitchAnalytics';

const Dashboard: React.FC = () => {
  const { currentFronters, switches, alters } = useSystem();
  const { profile } = useAuth();

  if (profile?.isSinglet) {
    return (
      <div className="space-y-8">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-[var(--text-primary)]">Hello, {profile?.displayName}</h2>
            <p className="text-[var(--text-secondary)]">Welcome back to HeadM8.</p>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-sm"
          >
            <h3 className="text-xl font-bold flex items-center gap-2 text-[var(--text-primary)] mb-4">
              <Book className="text-[var(--accent-main)]" />
              Your Diary
            </h3>
            <p className="text-[var(--text-secondary)] mb-6">Keep track of your thoughts and feelings in your private diary.</p>
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('setTab', { detail: 'diary' }))}
              className="px-6 py-2 bg-[var(--accent-main)] text-white rounded-xl font-bold hover:bg-[var(--accent-hover)] transition-all"
            >
              Open Diary
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-sm"
          >
            <h3 className="text-xl font-bold flex items-center gap-2 text-[var(--text-primary)] mb-4">
              <Users className="text-[var(--accent-main)]" />
              Community
            </h3>
            <p className="text-[var(--text-secondary)] mb-6">Connect with others and share your journey in the community feed.</p>
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('setTab', { detail: 'social' }))}
              className="px-6 py-2 bg-[var(--accent-main)] text-white rounded-xl font-bold hover:bg-[var(--accent-hover)] transition-all"
            >
              Explore Feed
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[var(--text-primary)]">Hello, {profile?.systemName}</h2>
          <p className="text-[var(--text-secondary)]">Welcome back to your system hub.</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Current Fronters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-2 bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold flex items-center gap-2 text-[var(--text-primary)]">
              <Users className="text-[var(--accent-main)]" />
              Currently Fronting
            </h3>
            <span className="text-xs font-medium px-2 py-1 bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 rounded-full">
              Live
            </span>
          </div>

          <div className="flex flex-wrap gap-6">
            {currentFronters.length > 0 ? (
              currentFronters.map((alter) => (
                <div key={alter.id} className="flex flex-col items-center gap-3">
                  <img
                    src={alter.avatarUrl || `https://ui-avatars.com/api/?name=${alter.name}`}
                    alt={alter.name}
                    className="w-20 h-20 rounded-2xl object-cover border-2 border-[var(--accent-main)] p-1 shadow-lg shadow-[var(--accent-glow)]"
                    referrerPolicy="no-referrer"
                  />
                  <span className="font-semibold text-[var(--text-primary)]">{alter.name}</span>
                </div>
              ))
            ) : (
              <p className="text-[var(--text-muted)] italic">No one is currently logged as fronting.</p>
            )}
          </div>
        </motion.div>

        {/* Quick Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-sm space-y-6"
        >
          <h3 className="text-xl font-bold flex items-center gap-2 text-[var(--text-primary)]">
            <Activity className="text-[var(--accent-main)]" />
            System Stats
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
              <p className="text-xs text-[var(--text-muted)] uppercase font-bold tracking-wider">Alters</p>
              <p className="text-2xl font-bold text-[var(--text-primary)]">{alters.length}</p>
            </div>
            <div className="p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
              <p className="text-xs text-[var(--text-muted)] uppercase font-bold tracking-wider">Switches</p>
              <p className="text-2xl font-bold text-[var(--text-primary)]">{switches.length}</p>
            </div>
          </div>

          <div className="pt-6 border-t border-[var(--bg-panel)]">
            <h4 className="text-sm font-bold flex items-center gap-2 mb-4 text-[var(--text-primary)]">
              <BarChart3 size={16} className="text-[var(--accent-main)]" />
              Top Fronters
            </h4>
            <SwitchAnalytics />
          </div>
        </motion.div>
      </div>

      {/* Recent Switches */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-sm"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center gap-2 text-[var(--text-primary)]">
            <Clock className="text-orange-500" />
            Recent Switches
          </h3>
        </div>

        <div className="space-y-4">
          {switches.slice(0, 5).map((log) => (
            <div key={log.id} className="flex items-center justify-between p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)] hover:border-[var(--accent-main)] transition-all">
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2">
                  {log.alterIds.map((id) => {
                    const alter = alters.find(a => a.id === id);
                    return (
                      <img
                        key={id}
                        src={alter?.avatarUrl || `https://ui-avatars.com/api/?name=${alter?.name || '?'}`}
                        alt={alter?.name}
                        className="w-8 h-8 rounded-full border-2 border-[var(--bg-surface)]"
                        referrerPolicy="no-referrer"
                      />
                    );
                  })}
                </div>
                <div>
                  <p className="font-medium text-[var(--text-primary)]">
                    {log.alterIds.map(id => alters.find(a => a.id === id)?.name).join(' & ')}
                  </p>
                  <p className="text-xs text-[var(--text-muted)]">{formatDate(log.timestamp)}</p>
                </div>
              </div>
              {log.notes && (
                <p className="text-sm text-[var(--text-secondary)] max-w-xs truncate italic">
                  "{log.notes}"
                </p>
              )}
            </div>
          ))}
          {switches.length === 0 && (
            <p className="text-center py-8 text-[var(--text-muted)] italic">No switch logs found.</p>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
