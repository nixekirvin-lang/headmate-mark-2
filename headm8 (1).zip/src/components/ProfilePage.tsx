import React, { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { db } from '../firebase';
import { doc, getDoc, collection, query, where, orderBy, limit, onSnapshot, updateDoc, arrayUnion, arrayRemove, addDoc, deleteDoc, increment, serverTimestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { UserPlus, UserMinus, MessageCircle, Shield, ShieldOff, Tag, AlertTriangle, Heart, MessageSquare, Plus, X, Edit2, Trash2 } from 'lucide-react';
import { UserProfile, Post, Alter, SwitchLog } from '../types';
import { formatDate, cn } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';
import PostCard from './PostCard';

interface ProfilePageProps {
  userId: string;
  onBack?: () => void;
  onOpenChat?: (userId: string) => void;
  onAuthorClick?: (uid: string) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ userId, onBack, onOpenChat, onAuthorClick }) => {
  const { user: currentUser, profile: currentProfile } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [currentFronters, setCurrentFronters] = useState<Alter[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);
  const [friendshipStatus, setFriendshipStatus] = useState<'none' | 'pending' | 'accepted'>('none');
  const [showCreatePost, setShowCreatePost] = useState(false);

  useEffect(() => {
    if (!userId) return;
    
    const unsubProfile = onSnapshot(doc(db, 'users', userId), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        setProfile(data);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${userId}`);
    });

    return unsubProfile;
  }, [userId]);

  useEffect(() => {
    if (!currentProfile || !userId) return;
    setIsFollowing(currentProfile.followingIds?.includes(userId) || false);
    if (currentProfile.friendIds?.includes(userId)) {
      setFriendshipStatus('accepted');
    }
  }, [currentProfile, userId]);

  useEffect(() => {
    if (!currentUser || !userId || friendshipStatus === 'accepted') return;

    const friendQ = query(
      collection(db, 'friendships'),
      where('user1Id', 'in', [currentUser.uid, userId]),
      where('user2Id', 'in', [currentUser.uid, userId]),
      where('status', '==', 'pending')
    );
    
    const unsubFriend = onSnapshot(friendQ, (snap) => {
      if (!snap.empty) {
        setFriendshipStatus('pending');
      } else {
        setFriendshipStatus('none');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'friendships');
    });

    return unsubFriend;
  }, [currentUser, userId, friendshipStatus]);

  useEffect(() => {
    if (!userId) return;
    // Fetch posts
    const postsQ = query(
      collection(db, 'posts'),
      where('systemId', '==', userId),
      where('visibility', '==', 'public'),
      orderBy('timestamp', 'desc'),
      limit(20)
    );
    const unsubPosts = onSnapshot(postsQ, (snap) => {
      setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() } as Post)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'posts');
      setLoading(false);
    });

    return unsubPosts;
  }, [userId]);

  useEffect(() => {
    if (!userId || !currentUser || !currentProfile) return;
    // Fetch current fronters - only if owner or friend
    let unsubSwitches = () => {};
    if (currentUser.uid === userId || currentProfile.friendIds?.includes(userId)) {
      const switchQ = query(
        collection(db, 'users', userId, 'switches'),
        orderBy('timestamp', 'desc'),
        limit(1)
      );
      unsubSwitches = onSnapshot(switchQ, async (snap) => {
        try {
          if (!snap.empty) {
            const lastSwitch = snap.docs[0].data() as SwitchLog;
            const alterPromises = lastSwitch.alterIds.map(id => getDoc(doc(db, 'users', userId, 'alters', id)));
            const alterSnaps = await Promise.all(alterPromises);
            setCurrentFronters(alterSnaps.map(s => ({ id: s.id, ...s.data() } as Alter)));
          } else {
            setCurrentFronters([]);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${userId}/switches`);
        }
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, `users/${userId}/switches`);
      });
    }
    return unsubSwitches;
  }, [userId, currentUser, currentProfile]);

  const handleFollow = async () => {
    if (!currentUser || !currentProfile) return;
    const isNowFollowing = !isFollowing;
    setIsFollowing(isNowFollowing);

    try {
      await updateDoc(doc(db, 'users', currentUser.uid), {
        followingIds: isNowFollowing ? arrayUnion(userId) : arrayRemove(userId)
      });
      await updateDoc(doc(db, 'users', userId), {
        followerIds: isNowFollowing ? arrayUnion(currentUser.uid) : arrayRemove(currentUser.uid)
      });

      if (isNowFollowing) {
        await addDoc(collection(db, 'notifications'), {
          recipientId: userId,
          senderId: currentUser.uid,
          senderName: currentProfile.displayName || currentProfile.systemName || 'User',
          senderAvatar: currentProfile.avatarUrl || null,
          type: 'follow',
          timestamp: new Date().toISOString(),
          isRead: false
        });
      }
    } catch (err) {
      console.error('Error following:', err);
      setIsFollowing(!isNowFollowing);
    }
  };

  const handleAddFriend = async () => {
    if (!currentUser || friendshipStatus !== 'none') return;
    try {
      await addDoc(collection(db, 'friendships'), {
        user1Id: currentUser.uid,
        user2Id: userId,
        status: 'pending',
        timestamp: new Date().toISOString()
      });
      
      await addDoc(collection(db, 'notifications'), {
        recipientId: userId,
        senderId: currentUser.uid,
        senderName: currentProfile.displayName || currentProfile.systemName || 'User',
        senderAvatar: currentProfile.avatarUrl || null,
        type: 'friend_request',
        timestamp: new Date().toISOString(),
        isRead: false
      });

      setFriendshipStatus('pending');
    } catch (err) {
      console.error('Error adding friend:', err);
    }
  };

  const handleLike = async (post: Post) => {
    if (!currentUser || !currentProfile) return;
    const isLiked = post.likedBy?.includes(currentUser.uid);
    try {
      await updateDoc(doc(db, 'posts', post.id), {
        likesCount: increment(isLiked ? -1 : 1),
        likedBy: isLiked ? arrayRemove(currentUser.uid) : arrayUnion(currentUser.uid)
      });

      if (!isLiked && post.systemId !== currentUser.uid) {
        await addDoc(collection(db, 'notifications'), {
          recipientId: post.systemId,
          senderId: currentUser.uid,
          senderName: currentProfile.displayName || currentProfile.systemName || 'User',
          senderAvatar: currentProfile.avatarUrl || null,
          type: 'like',
          postId: post.id,
          timestamp: new Date().toISOString(),
          isRead: false
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `posts/${post.id}`);
    }
  };

  const handleDelete = async (postId: string) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `posts/${postId}`);
    }
  };

  const startEdit = (post: Post) => {
    // For now, redirect to social feed to edit
    window.dispatchEvent(new CustomEvent('setTab', { detail: 'social' }));
    // We could pass the post to be edited via state or event
  };

  if (loading) return <div className="p-8 text-center text-[var(--text-muted)]">Loading profile...</div>;
  if (!profile) return <div className="p-8 text-center text-[var(--text-muted)]">Profile not found.</div>;

  return (
    <div className="space-y-8 pb-20">
      {/* Header / Banner */}
      <div className="relative h-64 rounded-[2.5rem] overflow-hidden bg-[var(--bg-panel)] border border-[var(--bg-panel)]">
        {profile.bannerUrl && (
          <img src={profile.bannerUrl} alt="Banner" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        
        <div className="absolute bottom-8 left-8 flex items-end gap-6">
          <img
            src={profile.avatarUrl || `https://ui-avatars.com/api/?name=${profile.displayName || profile.username || 'User'}`}
            alt="Avatar"
            className="w-32 h-32 rounded-3xl border-4 border-[var(--bg-surface)] object-cover shadow-2xl"
            referrerPolicy="no-referrer"
          />
          <div className="mb-2">
            <h2 className="text-3xl font-bold text-white tracking-tight">{profile.displayName || profile.systemName}</h2>
            <p className="text-white/80 font-medium">@{profile.username || 'user'}</p>
            {!profile.isSinglet && currentFronters.length > 0 && (
              <p className="text-[var(--accent-main)] font-bold text-sm mt-1">
                Currently Fronting: {currentFronters.map(f => f.name).join(', ')}
              </p>
            )}
          </div>
        </div>

        <div className="absolute bottom-8 right-8 flex gap-3">
          {currentUser?.uid === userId ? (
            <button
              onClick={() => setShowCreatePost(true)}
              className="px-6 py-2 bg-[var(--accent-main)] text-white rounded-xl font-bold transition-all flex items-center gap-2 shadow-lg shadow-[var(--accent-glow)]"
            >
              <Plus size={18} />
              Create Post
            </button>
          ) : (
            <>
              <button
                onClick={handleFollow}
                className={cn(
                  "px-6 py-2 rounded-xl font-bold transition-all flex items-center gap-2",
                  isFollowing ? "bg-white/20 text-white backdrop-blur-md" : "bg-[var(--accent-main)] text-white"
                )}
              >
                {isFollowing ? <UserMinus size={18} /> : <UserPlus size={18} />}
                {isFollowing ? 'Following' : 'Follow'}
              </button>
              <button
                onClick={handleAddFriend}
                disabled={friendshipStatus !== 'none'}
                className={cn(
                  "px-6 py-2 rounded-xl font-bold transition-all flex items-center gap-2",
                  friendshipStatus === 'accepted' ? "bg-green-500 text-white" : 
                  friendshipStatus === 'pending' ? "bg-orange-500 text-white" :
                  "bg-white text-black"
                )}
              >
                <UserPlus size={18} />
                {friendshipStatus === 'accepted' ? 'Friends' : 
                 friendshipStatus === 'pending' ? 'Pending' : 'Add Friend'}
              </button>
              <button 
                onClick={() => onOpenChat?.(userId)}
                className="p-2 bg-white/20 text-white backdrop-blur-md rounded-xl hover:bg-white/30 transition-all"
              >
                <MessageCircle size={24} />
              </button>
            </>
          )}
        </div>
      </div>

      <AnimatePresence>
        {showCreatePost && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-2xl bg-[var(--bg-surface)] rounded-[2.5rem] p-8 shadow-2xl border border-[var(--bg-panel)]"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">Create New Post</h3>
                <button onClick={() => setShowCreatePost(false)} className="p-2 hover:bg-[var(--bg-panel)] rounded-full transition-colors">
                  <X size={24} />
                </button>
              </div>
              {/* We can reuse the SocialFeed's post creation logic or just redirect */}
              <p className="text-[var(--text-secondary)] mb-6">Head over to the Community Feed to share your thoughts with everyone!</p>
              <div className="flex gap-4">
                <button 
                  onClick={() => {
                    setShowCreatePost(false);
                    window.dispatchEvent(new CustomEvent('setTab', { detail: 'social' }));
                  }}
                  className="flex-1 py-4 bg-[var(--accent-main)] text-white rounded-2xl font-bold hover:bg-[var(--accent-hover)] transition-all"
                >
                  Go to Community Feed
                </button>
                <button onClick={() => setShowCreatePost(false)} className="px-8 py-4 bg-[var(--bg-panel)] text-[var(--text-secondary)] rounded-2xl font-bold">
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar Info */}
        <div className="space-y-6">
          <section className="bg-[var(--bg-surface)] p-8 rounded-3xl border border-[var(--bg-panel)] shadow-sm">
            <h3 className="text-lg font-bold mb-4 text-[var(--text-primary)]">
              {profile.isSinglet ? 'About' : 'About System'}
            </h3>
            <p className="text-[var(--text-secondary)] whitespace-pre-wrap leading-relaxed">
              {profile.bio || "No bio provided."}
            </p>
            
            <div className="mt-8 pt-6 border-t border-[var(--bg-panel)] grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-[var(--text-primary)]">{profile.followerIds?.length || 0}</p>
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Followers</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-[var(--text-primary)]">{profile.followingIds?.length || 0}</p>
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Following</p>
              </div>
            </div>
          </section>

          {!profile.isSinglet && (
            <section className="bg-[var(--bg-surface)] p-8 rounded-3xl border border-[var(--bg-panel)] shadow-sm">
              <h3 className="text-lg font-bold mb-4 text-[var(--text-primary)]">System Members</h3>
              <div className="space-y-3">
                {currentFronters.map(alter => (
                  <div key={alter.id} className="flex items-center gap-3 p-3 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
                    <img src={alter.avatarUrl || `https://ui-avatars.com/api/?name=${alter.name}`} className="w-10 h-10 rounded-xl object-cover" />
                    <div>
                      <p className="font-bold text-sm text-[var(--text-primary)]">{alter.name}</p>
                      <p className="text-[10px] font-bold uppercase text-[var(--accent-main)]">Currently Fronting</p>
                    </div>
                  </div>
                ))}
                {currentFronters.length === 0 && (
                  <p className="text-sm text-[var(--text-muted)] italic">No active fronters visible.</p>
                )}
              </div>
            </section>
          )}
        </div>

        {/* Main Content: Posts */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-bold text-[var(--text-primary)] px-2">Forum Posts</h3>
          {posts.length > 0 ? (
            posts.map(post => (
              <PostCard
                key={post.id}
                post={post}
                onLike={() => handleLike(post)}
                onAuthorClick={onAuthorClick}
                onEdit={() => startEdit(post)}
                onDelete={() => handleDelete(post.id)}
              />
            ))
          ) : (
            <div className="bg-[var(--bg-surface)] rounded-3xl p-12 text-center border border-[var(--bg-panel)]">
              <p className="text-[var(--text-muted)]">No public posts yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;

