import React, { useState } from 'react';
import { useSystem } from '../SystemContext';
import { useAuth } from '../AuthContext';
import { db } from '../firebase';
import { collection, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Edit2, Trash2, X, Check, Shield, ShieldOff, Tag, Download, RefreshCw } from 'lucide-react';
import { Alter } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

const AlterManager: React.FC = () => {
  const { alters } = useSystem();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState<Alter | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [isImporting, setIsImporting] = useState<'sp' | 'pk' | null>(null);
  const [importToken, setImportToken] = useState('');
  const [importLoading, setImportLoading] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    avatarUrl: '',
    bannerUrl: '',
    tags: '',
    isPrivate: true,
    themeConfig: {
      background: '#f5f5f5',
      accent: '#a855f7',
      text: '#1a1a1a',
    }
  });

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const alterData = {
      ...formData,
      systemId: user.uid,
      tags: formData.tags.split(',').map(t => t.trim()).filter(t => t),
      createdAt: isEditing ? isEditing.createdAt : new Date().toISOString(),
    };

    try {
      if (isEditing) {
        await updateDoc(doc(db, 'users', user.uid, 'alters', isEditing.id), alterData);
      } else {
        await addDoc(collection(db, 'users', user.uid, 'alters'), alterData);
      }
      setIsAdding(false);
      setIsEditing(null);
      setFormData({ 
        name: '', 
        description: '', 
        avatarUrl: '', 
        bannerUrl: '', 
        tags: '', 
        isPrivate: true,
        themeConfig: { background: '#f5f5f5', accent: '#a855f7', text: '#1a1a1a' }
      });
    } catch (error) {
      handleFirestoreError(error, isEditing ? OperationType.UPDATE : OperationType.CREATE, `users/${user.uid}/alters`);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user || !window.confirm('Are you sure you want to delete this alter?')) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'alters', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/alters/${id}`);
    }
  };

  const openEdit = (alter: Alter) => {
    setIsEditing(alter);
    setFormData({
      name: alter.name,
      description: alter.description || '',
      avatarUrl: alter.avatarUrl || '',
      bannerUrl: alter.bannerUrl || '',
      tags: alter.tags?.join(', ') || '',
      isPrivate: alter.isPrivate ?? true,
      themeConfig: alter.themeConfig || { background: '#f5f5f5', accent: '#a855f7', text: '#1a1a1a' }
    });
    setIsAdding(true);
  };

  const handleImport = async () => {
    if (!user || !importToken || !isImporting) return;
    setImportLoading(true);
    setImportError(null);

    try {
      let importedAlters: any[] = [];

      if (isImporting === 'sp') {
        const response = await fetch('https://api.apparyllis.com/v1/members', {
          headers: { 'Authorization': importToken }
        });
        if (!response.ok) throw new Error('Failed to fetch from Simply Plural');
        const data = await response.json();
        importedAlters = data.map((m: any) => ({
          name: m.content.name,
          description: m.content.desc || '',
          avatarUrl: m.content.avatarUrl || '',
          bannerUrl: m.content.bannerUrl || '',
          tags: [],
          isPrivate: m.content.private ?? true,
          systemId: user.uid,
          createdAt: new Date().toISOString()
        }));
      } else {
        const response = await fetch('https://api.pluralkit.me/v2/systems/@me/members', {
          headers: { 'Authorization': importToken }
        });
        if (!response.ok) throw new Error('Failed to fetch from PluralKit');
        const data = await response.json();
        importedAlters = data.map((m: any) => ({
          name: m.name,
          description: m.description || '',
          avatarUrl: m.avatar_url || '',
          bannerUrl: m.banner || '',
          tags: [],
          isPrivate: m.privacy?.visibility === 'private',
          systemId: user.uid,
          createdAt: new Date().toISOString()
        }));
      }

      // Batch add to Firestore
      const batch = importedAlters.map(alter => 
        addDoc(collection(db, 'users', user.uid, 'alters'), alter)
      );
      try {
        await Promise.all(batch);
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/alters`);
      }

      setIsImporting(null);
      setImportToken('');
    } catch (err: any) {
      setImportError(err.message);
    } finally {
      setImportLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[var(--text-primary)]">Alter Management</h2>
          <p className="text-[var(--text-secondary)]">Document and manage your system's identities.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsImporting('sp')}
            className="flex items-center gap-2 px-4 py-2 bg-[var(--bg-surface)] text-[var(--text-secondary)] border border-[var(--bg-panel)] rounded-xl font-bold hover:bg-[var(--bg-panel)] transition-all text-sm"
          >
            <Download size={18} />
            Import SP
          </button>
          <button
            onClick={() => setIsImporting('pk')}
            className="flex items-center gap-2 px-4 py-2 bg-[var(--bg-surface)] text-[var(--text-secondary)] border border-[var(--bg-panel)] rounded-xl font-bold hover:bg-[var(--bg-panel)] transition-all text-sm"
          >
            <Download size={18} />
            Import PK
          </button>
          <button
            onClick={() => { setIsAdding(true); setIsEditing(null); }}
            className="flex items-center gap-2 px-6 py-3 bg-[var(--accent-main)] text-white rounded-2xl font-bold hover:bg-[var(--accent-hover)] transition-all shadow-lg shadow-[var(--accent-glow)]"
          >
            <Plus size={20} />
            Add Alter
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isImporting && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          >
            <div className="bg-[var(--bg-surface)] rounded-3xl p-8 w-full max-w-md shadow-2xl border border-[var(--bg-panel)]">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">
                  Import from {isImporting === 'sp' ? 'Simply Plural' : 'PluralKit'}
                </h3>
                <button onClick={() => setIsImporting(null)} className="p-2 hover:bg-[var(--bg-panel)] rounded-full text-[var(--text-secondary)]">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <p className="text-sm text-[var(--text-secondary)]">
                  {isImporting === 'sp' 
                    ? 'Enter your Simply Plural API Key. You can find this in Settings > API.' 
                    : 'Enter your PluralKit Token. You can get this by typing "pk;token" in Discord.'}
                </p>
                <input
                  type="password"
                  value={importToken}
                  onChange={e => setImportToken(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                  placeholder="Enter token..."
                />
                {importError && (
                  <p className="text-xs text-red-500 font-medium">{importError}</p>
                )}
                <button
                  onClick={handleImport}
                  disabled={importLoading || !importToken}
                  className="w-full py-4 bg-[var(--accent-main)] text-white rounded-2xl font-bold hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {importLoading ? <RefreshCw className="animate-spin" size={20} /> : <Download size={20} />}
                  {importLoading ? 'Importing...' : 'Start Import'}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {isAdding && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          >
            <div className="bg-[var(--bg-surface)] rounded-3xl p-8 w-full max-w-2xl shadow-2xl border border-[var(--bg-panel)] overflow-y-auto max-h-[90vh]">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">{isEditing ? 'Edit Alter' : 'New Alter'}</h3>
                <button onClick={() => setIsAdding(false)} className="p-2 hover:bg-[var(--bg-panel)] rounded-full text-[var(--text-secondary)]">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-[var(--text-muted)]">Name</label>
                    <input
                      required
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                      placeholder="e.g. Luna"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-[var(--text-muted)]">Tags (comma separated)</label>
                    <input
                      value={formData.tags}
                      onChange={e => setFormData({ ...formData, tags: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                      placeholder="e.g. Host, Protector"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase tracking-wider text-[var(--text-muted)]">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={e => setFormData({ ...formData, description: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none min-h-[100px]"
                    placeholder="Tell us about them..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-[var(--text-muted)]">Avatar URL</label>
                    <input
                      value={formData.avatarUrl}
                      onChange={e => setFormData({ ...formData, avatarUrl: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                      placeholder="https://..."
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-[var(--text-muted)]">Banner URL</label>
                    <input
                      value={formData.bannerUrl}
                      onChange={e => setFormData({ ...formData, bannerUrl: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                      placeholder="https://..."
                    />
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-[var(--bg-panel)]">
                  <label className="text-sm font-bold uppercase tracking-wider text-[var(--text-muted)]">Custom Theme (Optional)</label>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase text-[var(--text-muted)]">Background</label>
                      <input 
                        type="color" 
                        value={formData.themeConfig.background}
                        onChange={(e) => setFormData({ ...formData, themeConfig: { ...formData.themeConfig, background: e.target.value } })}
                        className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-[var(--bg-panel)]"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase text-[var(--text-muted)]">Accent</label>
                      <input 
                        type="color" 
                        value={formData.themeConfig.accent}
                        onChange={(e) => setFormData({ ...formData, themeConfig: { ...formData.themeConfig, accent: e.target.value } })}
                        className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-[var(--bg-panel)]"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase text-[var(--text-muted)]">Text</label>
                      <input 
                        type="color" 
                        value={formData.themeConfig.text}
                        onChange={(e) => setFormData({ ...formData, themeConfig: { ...formData.themeConfig, text: e.target.value } })}
                        className="w-full h-10 rounded-xl cursor-pointer bg-transparent border border-[var(--bg-panel)]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-[var(--bg-main)] rounded-2xl border border-[var(--bg-panel)]">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, isPrivate: !formData.isPrivate })}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
                      formData.isPrivate ? 'bg-[var(--bg-panel)] text-[var(--text-secondary)]' : 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                    }`}
                  >
                    {formData.isPrivate ? <Shield size={18} /> : <ShieldOff size={18} />}
                    {formData.isPrivate ? 'Private (System Only)' : 'Shared (Visible to Friends)'}
                  </button>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[var(--accent-main)] text-white rounded-2xl font-bold text-lg hover:bg-[var(--accent-hover)] transition-all shadow-xl shadow-[var(--accent-glow)]"
                >
                  {isEditing ? 'Update Alter' : 'Create Alter'}
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {alters.map((alter) => (
          <motion.div
            layout
            key={alter.id}
            className="group relative bg-[var(--bg-surface)] rounded-3xl overflow-hidden border border-[var(--bg-panel)] shadow-sm hover:shadow-xl transition-all"
          >
            <div className="h-24 bg-[var(--bg-main)] relative">
              {alter.bannerUrl && (
                <img src={alter.bannerUrl} alt="Banner" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              )}
              <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(alter)} className="p-2 bg-[var(--bg-surface)]/90 rounded-full shadow-sm hover:text-[var(--accent-main)] text-[var(--text-primary)]">
                  <Edit2 size={16} />
                </button>
                <button onClick={() => handleDelete(alter.id)} className="p-2 bg-[var(--bg-surface)]/90 rounded-full shadow-sm hover:text-red-500 text-[var(--text-primary)]">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            <div className="p-6 pt-0 -mt-10 relative">
              <img
                src={alter.avatarUrl || `https://ui-avatars.com/api/?name=${alter.name}`}
                alt={alter.name}
                className="w-20 h-20 rounded-2xl border-4 border-[var(--bg-surface)] object-cover shadow-md mb-4"
                referrerPolicy="no-referrer"
              />
              <div className="flex items-center gap-2 mb-1">
                <h4 className="text-xl font-bold text-[var(--text-primary)]">{alter.name}</h4>
                {alter.isPrivate ? <Shield size={14} className="text-[var(--text-muted)]" /> : <ShieldOff size={14} className="text-green-500" />}
              </div>
              <p className="text-sm text-[var(--text-secondary)] line-clamp-2 mb-4 min-h-[2.5rem]">
                {alter.description || 'No description provided.'}
              </p>
              <div className="flex flex-wrap gap-2">
                {alter.tags?.map(tag => (
                  <span key={tag} className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-1 bg-[var(--bg-panel)] text-[var(--text-secondary)] rounded-full">
                    <Tag size={10} />
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AlterManager;
