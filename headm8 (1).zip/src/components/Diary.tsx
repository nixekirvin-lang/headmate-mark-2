import React, { useState, useEffect } from 'react';
import { useSystem } from '../SystemContext';
import { useAuth } from '../AuthContext';
import { db } from '../firebase';
import { collection, addDoc, query, orderBy, onSnapshot, where } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { Book, Plus, Search, Calendar, Filter, Image as ImageIcon, Music, Smile } from 'lucide-react';
import { DiaryEntry } from '../types';
import { cn, formatDate } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

const Diary: React.FC = () => {
  const { alters } = useSystem();
  const { user } = useAuth();
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [selectedAlterId, setSelectedAlterId] = useState<string>('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAlterId, setFilterAlterId] = useState<string>('all');

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'users', user.uid, 'diary'),
      orderBy('timestamp', 'desc')
    );
    const unsub = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as DiaryEntry)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/diary`);
    });
    return unsub;
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedAlterId || !content) return;

    try {
      await addDoc(collection(db, 'users', user.uid, 'diary'), {
        systemId: user.uid,
        alterId: selectedAlterId,
        content,
        mood,
        timestamp: new Date().toISOString(),
      });
      setContent('');
      setMood('');
      setIsAdding(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/diary`);
    }
  };

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = entry.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAlter = filterAlterId === 'all' || entry.alterId === filterAlterId;
    return matchesSearch && matchesAlter;
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[var(--text-primary)]">Private Diary</h2>
          <p className="text-[var(--text-secondary)]">A completely private space for your alters to journal.</p>
        </div>
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[var(--accent-main)] text-white rounded-2xl font-bold hover:bg-[var(--accent-hover)] transition-all shadow-lg shadow-[var(--accent-glow)]"
        >
          <Plus size={20} />
          New Entry
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-xl"
          >
            <form onSubmit={handleSave} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Who is writing?</label>
                  <select
                    required
                    value={selectedAlterId}
                    onChange={e => setSelectedAlterId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                  >
                    <option value="">Select Alter...</option>
                    {alters.map(alter => (
                      <option key={alter.id} value={alter.id}>{alter.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Current Mood</label>
                  <div className="flex items-center gap-2">
                    <Smile size={20} className="text-[var(--text-muted)]" />
                    <input
                      value={mood}
                      onChange={e => setMood(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
                      placeholder="e.g. Calm, Anxious, Happy"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Entry Content</label>
                <textarea
                  required
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[var(--bg-panel)] bg-[var(--bg-main)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none min-h-[200px]"
                  placeholder="Write your thoughts here..."
                />
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  className="flex-1 py-4 bg-[var(--accent-main)] text-white rounded-2xl font-bold text-lg hover:bg-[var(--accent-hover)] transition-all shadow-xl shadow-[var(--accent-glow)]"
                >
                  Save Entry
                </button>
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-8 py-4 bg-[var(--bg-panel)] text-[var(--text-secondary)] rounded-2xl font-bold hover:bg-[var(--bg-surface)] transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={20} />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-[var(--bg-surface)] rounded-2xl border border-[var(--bg-panel)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
            placeholder="Search entries..."
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={20} className="text-[var(--text-muted)]" />
          <select
            value={filterAlterId}
            onChange={e => setFilterAlterId(e.target.value)}
            className="px-4 py-3 bg-[var(--bg-surface)] rounded-2xl border border-[var(--bg-panel)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-main)] outline-none"
          >
            <option value="all">All Alters</option>
            {alters.map(alter => (
              <option key={alter.id} value={alter.id}>{alter.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-6">
        {filteredEntries.map((entry) => {
          const alter = alters.find(a => a.id === entry.alterId);
          return (
            <motion.div
              layout
              key={entry.id}
              className="bg-[var(--bg-surface)] rounded-3xl p-8 border border-[var(--bg-panel)] shadow-sm"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <img
                    src={alter?.avatarUrl || `https://ui-avatars.com/api/?name=${alter?.name || '?'}`}
                    alt={alter?.name}
                    className="w-12 h-12 rounded-2xl object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="text-lg font-bold text-[var(--text-primary)]">{alter?.name || 'Unknown Alter'}</h4>
                    <p className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                      <Calendar size={12} />
                      {formatDate(entry.timestamp)}
                    </p>
                  </div>
                </div>
                {entry.mood && (
                  <span className="px-3 py-1 bg-[var(--accent-main)]/10 text-[var(--accent-main)] rounded-full text-xs font-bold uppercase tracking-wider">
                    {entry.mood}
                  </span>
                )}
              </div>
              <p className="text-[var(--text-secondary)] whitespace-pre-wrap leading-relaxed">
                {entry.content}
              </p>
            </motion.div>
          );
        })}
        {filteredEntries.length === 0 && (
          <div className="text-center py-20 bg-[var(--bg-surface)] rounded-3xl border border-dashed border-[var(--bg-panel)]">
            <Book size={48} className="mx-auto text-[var(--text-muted)] mb-4" />
            <p className="text-[var(--text-muted)] italic">No diary entries found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Diary;
